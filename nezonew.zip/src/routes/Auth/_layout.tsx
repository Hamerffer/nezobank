import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/Auth/_layout')({
  component: RouteComponent,
})

function RouteComponent() {
  return <div>Hello "/Auth/_layout"!</div>
}
