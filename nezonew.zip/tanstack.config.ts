export default {
  routesDir: './src/routes', // Path to your routes directory
  outDir: './src', // Output directory for routeTree.gen.ts
};
