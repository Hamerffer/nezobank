import { defineConfig } from 'vite'
import react from "@vitejs/plugin-react-swc";
import tailwindcss from '@tailwindcss/vite'
import { tanstackRouter } from '@tanstack/router-plugin/vite'
import path from 'path';
// https://vite.dev/config/
export default defineConfig({
  plugins: [ tailwindcss(),   tanstackRouter({
      target: 'react',
      autoCodeSplitting: true,
    }),react(),],
    server: {
      host:"0.0.0.0",
    },
     resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
})
